import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Camera, 
  Upload, 
  Sparkles, 
  RefreshCw, 
  Download, 
  Heart, 
  ChevronRight,
  User,
  Info,
  Check
} from 'lucide-react';
import { applyMakeup } from './services/geminiService';
import { cn } from './lib/utils';

interface MakeupStyle {
  id: string;
  name: string;
  description: string;
  emoji: string;
  prompt: string;
}

const MAKEUP_STYLES: MakeupStyle[] = [
  { 
    id: 'natural', 
    name: 'Natural Glow', 
    description: 'Enhance your features with a soft, "no-makeup" look.',
    emoji: '🌿',
    prompt: 'natural, "no-makeup" look, dewy skin, subtle lip tint, light mascara'
  },
  { 
    id: 'glam', 
    name: 'Hollywood Glam', 
    description: 'Dramatic red lips, winged eyeliner, and contoured cheeks.',
    emoji: '💃',
    prompt: 'Hollywood red carpet glam, bold red lipstick, sharp winged eyeliner, full lashes, contoured'
  },
  { 
    id: 'evening', 
    name: 'Evening Sultry', 
    description: 'Smokey eyes and nude lips, perfect for a night out.',
    emoji: '🌙',
    prompt: 'sultry evening makeup, dark smokey eyes, nude matte lipstick, radiant highlight'
  },
  { 
    id: 'edgy', 
    name: 'Modern Edgy', 
    description: 'Bold colors and experimental styles.',
    emoji: '🎨',
    prompt: 'avant-garde edgy makeup, holographic eyeshadow, dark bold lips, unique artistic touches'
  },
  { 
    id: 'sun-kissed', 
    name: 'Sun-Kissed', 
    description: 'Warm bronzed skin and coral tones.',
    emoji: '☀️',
    prompt: 'sun-kissed bronze look, coral blush and lips, shimmering gold eyelids'
  }
];

export default function App() {
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [mimeType, setMimeType] = useState<string>('');
  const [transformedImage, setTransformedImage] = useState<string | null>(null);
  const [selectedStyle, setSelectedStyle] = useState<MakeupStyle | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        setError('Please upload an image file.');
        return;
      }
      
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target?.result as string;
        setOriginalImage(base64);
        setMimeType(file.type);
        setTransformedImage(null);
        setError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const processMakeup = async () => {
    if (!originalImage || !selectedStyle) return;

    setIsProcessing(true);
    setError(null);
    
    try {
      // Remove data:image/...;base64, prefix for the API
      const base64Data = originalImage.split(',')[1];
      const result = await applyMakeup(base64Data, mimeType, selectedStyle.prompt);
      
      if (result) {
        setTransformedImage(result);
      } else {
        setError('Failed to generate image. Please try again.');
      }
    } catch (err) {
      setError('An error occurred during processing. Please try a different photo or style.');
      console.error(err);
    } finally {
      setIsProcessing(false);
    }
  };

  const reset = () => {
    setOriginalImage(null);
    setTransformedImage(null);
    setSelectedStyle(null);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-[#FDFCFB] text-[#1A1A1A] font-sans italic-small selection:bg-rose-100 italic-small">
      {/* Background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] right-[-10%] w-[40%] h-[40%] bg-rose-50 rounded-full blur-3xl opacity-50" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[40%] h-[40%] bg-orange-50 rounded-full blur-3xl opacity-50" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-8">
        {/* Header */}
        <header className="flex justify-between items-center mb-12">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-2"
          >
            <div className="w-10 h-10 bg-rose-500 rounded-full flex items-center justify-center text-white shadow-lg">
              <Sparkles size={24} />
            </div>
            <span className="text-2xl font-serif font-bold tracking-tight bg-gradient-to-r from-rose-600 to-orange-500 bg-clip-text text-transparent">
              BellaLook AI
            </span>
          </motion.div>
          
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium opacity-60">
            <a href="#" className="hover:opacity-100 transition-opacity">Galería</a>
            <a href="#" className="hover:opacity-100 transition-opacity">Modelos</a>
            <a href="#" className="hover:opacity-100 transition-opacity">Tutoriales</a>
          </nav>

          <button className="flex items-center gap-2 px-4 py-2 bg-white/50 backdrop-blur-sm border border-rose-100 rounded-full text-sm font-semibold hover:bg-white transition-all shadow-sm">
            <User size={16} />
            <span>Mi Perfil</span>
          </button>
        </header>

        <main>
          {!originalImage ? (
            <motion.section 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center py-12 md:py-24 max-w-3xl mx-auto"
            >
              <h1 className="text-5xl md:text-7xl font-serif font-light leading-tight mb-6">
                Descubre tu <span className="italic">mejor versión</span> con IA
              </h1>
              <p className="text-lg text-gray-500 mb-10 leading-relaxed px-4">
                Sube una foto de tu rostro y deja que nuestra inteligencia artificial encuentre el estilo de maquillaje perfecto para ti. Totalmente gratis, instantáneo y profesional.
              </p>
              
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="group relative cursor-pointer inline-block"
              >
                <div className="absolute -inset-1 bg-gradient-to-r from-rose-400 to-orange-400 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000 group-hover:duration-200"></div>
                <div className="relative flex items-center gap-3 px-8 py-4 bg-white rounded-2xl border border-rose-100 shadow-xl transition-all active:scale-95">
                  <Upload className="text-rose-500" />
                  <span className="text-lg font-semibold">Subir Foto del Rostro</span>
                </div>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleFileUpload} 
                  accept="image/*" 
                  className="hidden" 
                />
              </div>
              
              <div className="mt-12 flex flex-wrap justify-center gap-4 text-xs font-medium text-gray-400 uppercase tracking-widest">
                <span className="flex items-center gap-1"><Check size={14} className="text-green-500" /> Privacidad Garantizada</span>
                <span className="flex items-center gap-1"><Check size={14} className="text-green-500" /> Procesamiento en Tiempo Real</span>
                <span className="flex items-center gap-1"><Check size={14} className="text-green-500" /> Resultados Ultra-Realistas</span>
              </div>

              {/* Inspiration Gallery */}
              <div className="mt-24 text-left">
                <h3 className="text-sm uppercase tracking-[0.2em] font-bold text-rose-400 mb-8 text-center">Inspiración Diaria</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  {[
                    { style: 'Natural', url: 'https://images.unsplash.com/photo-1548142813-c348350df52b?auto=format&fit=crop&q=80&w=400' },
                    { style: 'Glam', url: 'https://images.unsplash.com/photo-1512496015851-a90fb38ba796?auto=format&fit=crop&q=80&w=400' },
                    { style: 'Edgy', url: 'https://images.unsplash.com/photo-1596704017254-9b121068fb29?auto=format&fit=crop&q=80&w=400' },
                    { style: 'Sultry', url: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&q=80&w=400' }
                  ].map((item, i) => (
                    <motion.div 
                      key={i}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: i * 0.1 }}
                      className="group relative aspect-[4/5] rounded-3xl overflow-hidden shadow-lg border border-rose-50"
                    >
                      <img src={item.url} alt={item.style} className="w-full h-full object-cover grayscale-[0.2] transition-all group-hover:grayscale-0 group-hover:scale-110" referrerPolicy="no-referrer" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-bottom p-6 flex flex-col justify-end opacity-0 group-hover:opacity-100 transition-opacity">
                        <p className="text-white font-serif italic text-lg">{item.style}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.section>
          ) : (
            <div className="grid lg:grid-cols-2 gap-12 items-start mt-8">
              {/* Left Column: Image Display */}
              <motion.div 
                layout
                className="space-y-6"
              >
                <div className="relative aspect-[3/4] bg-white rounded-[2rem] shadow-2xl overflow-hidden border border-rose-50">
                  <AnimatePresence mode="wait">
                    {!transformedImage ? (
                      <motion.img 
                        key="original"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        src={originalImage} 
                        alt="Original" 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <motion.div 
                        key="transformed"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="relative w-full h-full"
                      >
                        <img 
                          src={transformedImage} 
                          alt="Transformed" 
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute top-4 left-4 flex gap-2">
                           <span className="px-3 py-1 bg-rose-500 text-white text-xs font-bold rounded-full shadow-lg flex items-center gap-1">
                             <Sparkles size={12} />
                             IA GENERADA
                           </span>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {isProcessing && (
                    <div className="absolute inset-0 bg-white/40 backdrop-blur-md flex flex-col items-center justify-center">
                      <motion.div 
                        animate={{ rotate: 360 }}
                        transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
                        className="text-rose-500 mb-4"
                      >
                        <RefreshCw size={48} />
                      </motion.div>
                      <p className="text-rose-600 font-semibold animate-pulse text-center px-6">Aplicando maquillaje artístico con IA...</p>
                      <p className="text-xs text-rose-400 mt-2">Usando Gemini 2.5 Vision</p>
                    </div>
                  )}
                </div>

                <div className="flex gap-4">
                  <button 
                    onClick={reset}
                    className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-gray-100 hover:bg-gray-200 rounded-xl font-semibold transition-colors"
                  >
                    <RefreshCw size={20} />
                    <span>Nueva Foto</span>
                  </button>
                  {transformedImage && (
                    <a 
                      href={transformedImage} 
                      download="bellalook-ai-makeup.png"
                      className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-rose-600 text-white hover:bg-rose-700 rounded-xl font-semibold transition-all shadow-lg hover:shadow-rose-200"
                    >
                      <Download size={20} />
                      <span>Descargar</span>
                    </a>
                  )}
                </div>
              </motion.div>

              {/* Right Column: Controls */}
              <div className="space-y-8">
                <div>
                  <h2 className="text-3xl font-serif mb-2">Selecciona un Estilo</h2>
                  <p className="text-gray-500">¿Qué look te gustaría probar hoy?</p>
                </div>

                <div className="space-y-4">
                  {MAKEUP_STYLES.map((style) => (
                    <motion.div
                      key={style.id}
                      whileHover={{ x: 4 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => !isProcessing && setSelectedStyle(style)}
                      className={cn(
                        "group cursor-pointer p-4 rounded-2xl border transition-all flex items-center gap-4",
                        selectedStyle?.id === style.id 
                          ? "bg-rose-50 border-rose-200 shadow-md ring-1 ring-rose-200" 
                          : "bg-white border-gray-100 hover:border-rose-100 hover:shadow-sm"
                      )}
                    >
                      <div className={cn(
                        "w-12 h-12 rounded-xl flex items-center justify-center text-2xl transition-transform group-hover:scale-110",
                        selectedStyle?.id === style.id ? "bg-white shadow-sm" : "bg-gray-50"
                      )}>
                        {style.emoji}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-bold text-gray-900">{style.name}</h4>
                        <p className="text-sm text-gray-500">{style.description}</p>
                      </div>
                      {selectedStyle?.id === style.id && (
                        <div className="w-6 h-6 bg-rose-500 rounded-full flex items-center justify-center text-white">
                          <Check size={14} />
                        </div>
                      )}
                    </motion.div>
                  ))}
                </div>

                {error && (
                  <div className="p-4 bg-orange-50 border border-orange-100 rounded-xl flex gap-3 text-orange-700 text-sm">
                    <Info size={18} className="shrink-0" />
                    <p>{error}</p>
                  </div>
                )}

                <button
                  disabled={!selectedStyle || isProcessing}
                  onClick={processMakeup}
                  className={cn(
                    "w-full py-5 rounded-2xl font-bold text-lg flex items-center justify-center gap-3 transition-all relative overflow-hidden group",
                    !selectedStyle || isProcessing
                      ? "bg-gray-200 text-gray-400 cursor-not-allowed"
                      : "bg-gradient-to-r from-rose-500 to-orange-500 text-white shadow-xl shadow-rose-200 hover:shadow-rose-300"
                  )}
                >
                  <Sparkles size={24} />
                  <span>{isProcessing ? "Procesando..." : "Aplicar Estilo Mágico"}</span>
                  
                  {selectedStyle && !isProcessing && (
                    <motion.div 
                      className="absolute inset-0 bg-white/20 -translate-x-full group-hover:translate-x-full transition-transform duration-1000"
                    />
                  )}
                </button>

                <div className="pt-8 grid grid-cols-3 gap-4">
                  <div className="p-4 bg-white border border-gray-100 rounded-2xl text-center">
                    <p className="text-xs uppercase text-gray-400 font-bold mb-1">Modelo</p>
                    <p className="font-serif">Gemini AI</p>
                  </div>
                  <div className="p-4 bg-white border border-gray-100 rounded-2xl text-center">
                    <p className="text-xs uppercase text-gray-400 font-bold mb-1">Costo</p>
                    <p className="font-serif text-green-600">Gratis</p>
                  </div>
                  <div className="p-4 bg-white border border-gray-100 rounded-2xl text-center">
                    <p className="text-xs uppercase text-gray-400 font-bold mb-1">Calidad</p>
                    <p className="font-serif">HD+</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>

        <footer className="mt-24 pt-8 border-t border-gray-100 text-center text-sm text-gray-400 pb-12">
          <p>© 2026 BellaLook AI. Potenciado por Inteligencia Artificial de Google.</p>
          <div className="flex justify-center gap-6 mt-4">
            <a href="#" className="hover:text-rose-500 transition-colors">Términos</a>
            <a href="#" className="hover:text-rose-500 transition-colors">Privacidad</a>
            <a href="#" className="hover:text-rose-500 transition-colors">Contacto</a>
          </div>
        </footer>
      </div>
    </div>
  );
}
