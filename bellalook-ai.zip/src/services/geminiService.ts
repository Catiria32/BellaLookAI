import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function applyMakeup(imageBase64: string, mimeType: string, style: string): Promise<string | null> {
  try {
    const prompt = `Apply a professional, high-quality makeup transformation to the person in this image. 
    Style requested: ${style}. 
    Ensure the person's identity and facial structure remain recognizable, but enhance their look with realistic makeup including foundation, eyeshadow, eyeliner, lipstick, and contouring as appropriate for the ${style} aesthetic. 
    The output should be a single image of the same person with the makeup applied. 
    Focus on photorealistic results.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              data: imageBase64,
              mimeType: mimeType,
            },
          },
          {
            text: prompt,
          },
        ],
      },
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    
    return null;
  } catch (error) {
    console.error("Error applying makeup:", error);
    throw error;
  }
}
